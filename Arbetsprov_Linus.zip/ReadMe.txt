Tools used:
Microsoft Visual Studio Community 2019
Microsoft SQL Server Management Studio
Postman


1. Database creation
CREATE DATABASE CustomerDB;

CREATE TABLE Customers(
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[PersonalID] [nvarchar](12) NOT NULL,
	[Email] [nvarchar](320) NOT NULL,
	[Adress] [nvarchar](max) NOT NULL,
	[Telephone] [nvarchar](15) NOT NULL);
COMMIT;

--Dummy Data
INSERT INTO Customers VALUES ('199107220692', 'linus.dbergefur@gmail.com', 'Sweden 17546', '+46732396970');
INSERT INTO Customers VALUES ('201706271111', 'linnar.dbergefur@gmail.com', 'Norway 11111', '+47732396970');
INSERT INTO Customers VALUES ('201903082222', 'julius.dbergefur@gmail.com', 'Norway 22222', '+47732396970');

COMMIT;


2.Setting up 
-Open CustomerAPI.sln from Visual Studio Solution Explorer
-Replace [YOUR SERVER HERE] with the name of your server, within ValuesController on line 17
-Run
-Run Postman and press + to add an untitled request
-Paste the request URL into the text box next to the send button. (https://localhost:44357/api/values)
-Press Send
-Add "/1"to the URL to search for or delete the customer with ID 1 etc.

