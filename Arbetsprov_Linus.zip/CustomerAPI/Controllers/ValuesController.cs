﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Data;
using System.Data.SqlClient;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;

namespace CustomerAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController : ControllerBase
    {
        SqlConnection con = new SqlConnection(@"server=(LocalDb)\[YOUR SERVER HERE]; database=CustomerDB; Integrated Security=true;");
        // GET api/values
        [HttpGet]
        public string Get()
        {
            //return new string[] { "value1", "value2" };
            SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Customers", con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                return JsonConvert.SerializeObject(dt);
            }
            else
            {
                return "No data found.";
            }
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public string Get([FromBody] string id)
        {
            SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Customers WHERE ID = " + id, con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                return JsonConvert.SerializeObject(dt);
            }
            else
            {
                return "No data found.";
            }
        }

        // POST api/values
        //[HttpPost]
        //public string Post([FromBody] string value1, string value2, string value3, string value4)
        //public string Post([FromBody] string value)
        //{
        //    SqlCommand cmd = new SqlCommand("INSERT INTO Customers VALUES('" + value + "')", con);
        //    con.Open();
        //    int i = cmd.ExecuteNonQuery();
        //    con.Close();
        //
        //    if (i == 1)
        //    {
        //        return "Registered ID:" + value + "' successfully.";
        //    }
        //    else
        //    {
        //        return "Failed to register.";
        //    }
        //}

        // PUT api/values/5
        //[HttpPut("{id}")]
        //public string Put(int id, [FromBody] string value)
        //{
        //    SqlCommand cmd = new SqlCommand("UPDATE Customers SET PersonalID = '" + value + "' WHERE ID ='" + id + "')", con);
        //    con.Open();
        //    int i = cmd.ExecuteNonQuery();
        //    con.Close();
        //
        //    if (i == 1)
        //    {
        //        return "Updated ID:" + id + "with with info: " + value;
        //    }
        //    else
        //    {
        //        return "Failed to update.";
        //    }
        //}

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public string Delete(int id)
        {
            SqlCommand cmd = new SqlCommand("DELETE FROM Customers WHERE ID = " + id, con);
            con.Open();
            int i = cmd.ExecuteNonQuery();
            con.Close();

            if (i == 1)
            {
                return "Deleted info from ID:" + id;
            }
            else
            {
                return "Failed to delete.";
            }
        }
    }
}
